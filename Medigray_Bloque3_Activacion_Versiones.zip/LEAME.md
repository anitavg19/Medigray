# Medigray Bloque 3: activación controlada

**No migrar datos oficiales ni usar en producción sin validación.** Instalar sobre Medigray v2 con Bloques 1 y 2.

1. Detener servidor. Respaldar `storage/` fuera de Codespaces.
2. Subir los cuatro archivos a la misma carpeta que `app.py`.
3. `python instalar_bloque3.py`
4. `python -m py_compile app.py medigray_bloque3.py`
5. `python -m uvicorn app:app --host 0.0.0.0 --port 8000`
6. Abrir `/activacion-versiones`.

### Limitaciones
- Solo activa inmediatamente (fecha actual), no programa activaciones futuras.
- Exige PDF en almacenamiento local, solicitud aprobada y fecha de aprobación. No habilita aún PDF originado únicamente en Drive.
- Antes de iniciar, versiones iniciales sin control de cambio requieren flujo excepcional diseñado y autorizado.
- Registra transición por fecha, pero no crea un bloqueo automático de Compras al vencer la transición.
- No confirma automáticamente al proveedor, ni certifica autorización sanitaria externa.
- Una aplicación farmacéutica oficial necesita validación y pruebas de integridad documental.
