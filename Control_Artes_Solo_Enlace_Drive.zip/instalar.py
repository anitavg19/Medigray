from pathlib import Path
from datetime import datetime
import ast, shutil, sys
from jinja2 import Environment
root=Path.cwd()
app=root/'app.py'; form=root/'templates'/'art_form.html'
if not app.is_file() or not form.is_file():
    sys.exit('EJECUTE desde la carpeta del proyecto (app.py y templates/art_form.html requeridos).')
s=app.read_text(encoding='utf-8'); lines=s.splitlines(keepends=True)
tr=ast.parse(s)
routes=[n for n in tr.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name=='art_create']
if len(routes)!=1: sys.exit('No se encontró una única función art_create; no se cambió nada.')
n=routes[0]
# Only replace known compatible function, preserving all other route registration and modules.
old=''.join(lines[n.lineno-1:n.end_lineno]);
if "INSERT INTO arts(" not in old or "art_document_links" not in s:
    sys.exit('Versión del servidor incompatible; no se cambió nada.')
if 'CONTROL_ARTES_SOLO_DRIVE_SEGURO_V2' in s:
    print('La actualización ya está instalada.');sys.exit(0)
new='''# CONTROL_ARTES_SOLO_DRIVE_SEGURO_V2
@app.post('/artes/nuevo')
def art_create(req:Request, csrf_token:str=Form(...), master_code:str=Form(...),
               sap_code:str=Form(...), company_id:int=Form(...),
               product:str=Form(...), packaging_type:str=Form(...),
               description:str=Form(''), drive_url:str=Form(...)):
    from urllib.parse import urlparse, parse_qs
    import re
    u=require(req,'Administrador','Regulatorios')
    csrf(req,csrf_token)
    company_access(u,company_id)
    module_access(u,company_id,'artes')
    if not all(x.strip() for x in (master_code,sap_code,product,packaging_type)):
        raise HTTPException(400,'Complete los campos obligatorios')
    drive_url=drive_url.strip()
    parsed=urlparse(drive_url)
    host=(parsed.hostname or '').lower()
    if parsed.scheme!='https' or host not in ('drive.google.com','docs.google.com'):
        raise HTTPException(400,'Pegue un enlace HTTPS de Google Drive o Google Docs')
    target = bool(re.search(r'/(file|document|spreadsheets|presentation)/d/[^/]+',parsed.path))
    target = target or (host=='drive.google.com' and parsed.path=='/open' and bool(parse_qs(parsed.query).get('id')))
    if not target:
        raise HTTPException(400,'Pegue el enlace directo a un archivo de Drive, no a una carpeta')
    with conn() as c:
        try:
            cur=c.execute('INSERT INTO arts(master_code,sap_code,company_id,product,packaging_type,description,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)',(master_code.strip(),sap_code.strip(),company_id,product.strip(),packaging_type.strip(),description.strip(),u['id'],utc()))
        except sqlite3.IntegrityError:
            raise HTTPException(400,'Código maestro duplicado o empresa inexistente')
        aid=cur.lastrowid
        c.execute('INSERT INTO art_document_links(company_id,art_id,url,description,created_by,created_at) VALUES(?,?,?,?,?,?)',(company_id,aid,drive_url,'Documento inicial en Google Drive',u['id'],utc()))
        audit(c,u['id'],'CREAR','Arte',aid,new={'master_code':master_code,'sap_code':sap_code,'document_mode':'drive'})
    return go(f'/artes/{aid}')
'''
start=min([n.lineno]+[d.lineno for d in n.decorator_list]) - 1
new_code=''.join(lines[:start])+new+'\n'+''.join(lines[n.end_lineno:])
ast.parse(new_code)
form_code='''{% extends 'base.html' %}
{% block content %}
<h1>Nuevo arte maestro</h1>
<section class="panel">
<form method="post" action="/artes/nuevo">
  <input type="hidden" name="csrf_token" value="{{ csrf }}">
  <div class="grid">
    <div><label>Código maestro *</label><input name="master_code" required placeholder="ART-000145"></div>
    <div><label>Código SAP *</label><input name="sap_code" required placeholder="10004567"></div>
    <div><label>Empresa *</label><select name="company_id" required>
      {% for c in companies %}<option value="{{c.id}}" {% if c.id == empresa_actual %}selected{% endif %}>{{c.name}}</option>{% endfor %}
    </select></div>
    <div><label>Producto *</label><input name="product" required></div>
    <div><label>Tipo de empaque *</label><select name="packaging_type" required>
      <option>Etiqueta</option><option>Inserto</option><option>Empaque primario</option><option>Empaque secundario</option><option>Otro</option>
    </select></div>
  </div>
  <label>Descripción</label><textarea name="description"></textarea>
  <div class="panel" style="background:#F5F9FD">
    <h2>Documento de Google Drive</h2>
    <label for="drive_url">Enlace del arte *</label>
    <input id="drive_url" type="url" name="drive_url" required placeholder="https://drive.google.com/file/d/ID/view">
    <p class="muted">Solo debe pegar el enlace de un archivo de Drive. El archivo permanece en Drive y debe tener permisos adecuados.</p>
  </div>
  <button type="submit" class="btn">Guardar arte</button>
  <a class="btn gray" href="/">Cancelar</a>
</form>
</section>
{% endblock %}
'''
Environment().parse(form_code)
backup=root/'respaldos'/('solo_drive_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
backup.mkdir(parents=True,exist_ok=True)
shutil.copy2(app,backup/'app.py');shutil.copy2(form,backup/'art_form.html')
app.write_text(new_code,encoding='utf-8');form.write_text(form_code,encoding='utf-8')
print('CORRECTO: Nuevo arte solo solicita enlace a Google Drive.')
print('Respaldo:',backup)
print('Sin cambios en storage ni otras rutas.')
