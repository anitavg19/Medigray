"""Instalador idempotente. Ejecutar desde la raíz del proyecto."""
from pathlib import Path
import shutil, datetime, ast, sys
root=Path.cwd()
app=root/"app.py"
templates=root/"templates"
source=Path(__file__).resolve().parent
if not app.exists() or not templates.is_dir():
    sys.exit("ERROR: ejecute desde /workspaces/Medigray (deben existir app.py y templates/)")
content=app.read_text(encoding="utf8")
if "def home(req:Request" not in content or "@app.get('/artes/{art_id}')" not in content:
    sys.exit("ERROR: app.py no coincide con la versión analizada. No se hicieron cambios.")
if "listado_artes_vigentes" in content or "CONTROL_ARTES_VIGENTES_DASHBOARD_V1" in content:
    sys.exit("La pantalla ya parece instalada; no se hicieron cambios.")
if "app.get('/artes/vigentes')" in content or 'app.get("/artes/vigentes")' in content:
    sys.exit("ERROR: Ya existe una ruta /artes/vigentes en app.py. Revise antes de instalar.")
anchor="@app.get('/artes/{art_id}')"
injection="""# CONTROL_ARTES_VIGENTES_DASHBOARD_V1
from artes_vigentes_dashboard import register as _register_vigentes_dashboard
_register_vigentes_dashboard(app, conn, require, view, company_ids, module_access)

"""
updated=content.replace(anchor,injection+anchor,1)
ast.parse(updated)
ast.parse((source/"artes_vigentes_dashboard.py").read_text(encoding="utf8"))
tag=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
backup=root/"respaldos"/f"vigentes_antes_{tag}"
backup.mkdir(parents=True,exist_ok=True)
shutil.copy2(app,backup/"app.py")
target=templates/"artes_vigentes_dashboard.html"
if target.exists(): shutil.copy2(target,backup/target.name)
shutil.copy2(source/"artes_vigentes_dashboard.py",root/"artes_vigentes_dashboard.py")
shutil.copy2(source/"artes_vigentes_dashboard.html",target)
app.write_text(updated,encoding="utf8")
print("INSTALADO: /artes/vigentes + dashboard de seguimiento 3 y 6 meses")
print("RESPALDO:",backup)
print("La base de datos no se ha modificado.")
