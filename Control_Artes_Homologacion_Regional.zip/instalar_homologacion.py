"""Instalador conservador para la extensión de homologación regional."""
from pathlib import Path
from datetime import datetime
import shutil
import sys
from jinja2 import Environment

root = Path(__file__).resolve().parent
project = Path.cwd()
app = project / 'app.py'
home = project / 'templates' / 'home.html'
base = project / 'templates' / 'base.html'
module_dst = project / 'homologacion_region.py'
tpl_dst = [project / 'templates' / p for p in ('homologacion.html', 'homologacion_detalle.html')]
source = root / 'homologacion_region.py'
src_tpls = [root / 'templates' / p.name for p in tpl_dst]
needed = [app, home, base, source, *src_tpls]
missing = [str(p) for p in needed if not p.is_file()]
if missing: sys.exit('Archivos faltantes: ' + ', '.join(missing))
code = app.read_text(encoding='utf-8')
original_home = home.read_text(encoding='utf-8')
if 'CONTROL_ARTES_HOMOLOGACION_V1' in code or module_dst.exists() or any(t.exists() for t in tpl_dst):
    sys.exit('La extensión parece instalada. No se sobrescribió ningún archivo.')
expected = ['app = FastAPI(', 'def conn(', 'def require(', 'def csrf(', 'def view(', 'def go(', 'def company_access(', 'def audit(', 'def utc(']
if any(s not in code for s in expected):
    sys.exit('Estructura de app.py diferente a la compatible. No se realizaron cambios.')
if 'class="action-grid"' not in original_home or '{% extends' not in original_home:
    sys.exit('Plantilla de Inicio no compatible. No se realizaron cambios.')
if "{% block content %}" not in base.read_text(encoding='utf-8'):
    sys.exit('Plantilla base no compatible. No se realizaron cambios.')
# La importación debe quedar antes del bloque __main__ para preservar comandos CLI.
marker = "# CONTROL_ARTES_HOMOLOGACION_V1\nfrom homologacion_region import montar_homologacion\nmontar_homologacion(app, conn, require, csrf, view, go, company_access, audit, utc)\n\n"
if "if __name__=='__main__':" in code:
    code = code.replace("if __name__=='__main__':", marker + "if __name__=='__main__':", 1)
else:
    code += '\n' + marker
# La tarjeta va en Inicio, sin añadir enlaces al menú lateral ya simplificado.
new_card = '''  <a class="action-card" href="/homologacion"><span class="action-icon">◎</span><strong>Homologación regional</strong><p>Compare artes por país, identifique variantes y oportunidades de unificación.</p><span class="action-arrow">Abrir →</span></a>\n'''
anchor = '<section class="action-grid" aria-label="Accesos rápidos">'
if anchor in original_home:
    pos = original_home.find('</section>', original_home.find(anchor))
    if pos < 0: sys.exit('No se encontró cierre de la sección de tarjetas. Sin cambios.')
    new_home = original_home[:pos] + new_card + original_home[pos:]
else:
    anchor = '<div class="section-heading" id="herramientas">'
    if anchor not in original_home: sys.exit('No hay punto seguro de inserción. Sin cambios.')
    new_home=original_home.replace(anchor, '<div class="panel"><a class="btn" href="/homologacion">◎ Homologación regional</a></div>\n'+anchor,1)
compile(code, str(app), 'exec')
compile(source.read_text(encoding='utf-8'),str(source),'exec')
for p in src_tpls: Environment().parse(p.read_text(encoding='utf-8'))
Environment().parse(new_home)
# Backup y escritura solo tras validaciones.
backup = project / 'respaldos' / ('homologacion_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
backup.mkdir(parents=True, exist_ok=False)
shutil.copy2(app,backup/'app.py')
shutil.copy2(home,backup/'home.html')
try:
    shutil.copy2(source,module_dst)
    for src, dst in zip(src_tpls,tpl_dst): shutil.copy2(src,dst)
    app.write_text(code,encoding='utf-8')
    home.write_text(new_home,encoding='utf-8')
except Exception:
    shutil.copy2(backup/'app.py',app)
    shutil.copy2(backup/'home.html',home)
    for p in [module_dst,*tpl_dst]: p.unlink(missing_ok=True)
    raise
print('HOMOLOGACIÓN REGIONAL INSTALADA')
print('Respaldo de app.py y home.html:',backup)
print('Próximo paso: reiniciar Uvicorn y abrir /homologacion')
print('Se crearán tablas nuevas al iniciar el servidor; no se eliminan registros existentes.')
