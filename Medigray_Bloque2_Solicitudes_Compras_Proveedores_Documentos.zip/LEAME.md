# Medigray — Bloque 2

## Instalación en GitHub Codespaces

1. Detenga Uvicorn con `Ctrl+C` (para mantener consistencia durante la migración).
2. Antes de copiar, haga respaldo externo de `storage/`, incluyendo `.session-secret` y `files/`.
3. Extraiga el ZIP en su equipo y suba **los tres elementos** a la raíz de `/workspaces/Medigray`: `instalar_bloque2.py`, `medigray_bloque2.py` y la carpeta `templates_bloque2` con sus cuatro HTML. No reemplace `app.py`.
4. Ejecute `python instalar_bloque2.py`.
5. Verifique `python -m py_compile app.py medigray_bloque2.py`.
6. Inicie `python -m uvicorn app:app --host 0.0.0.0 --port 8000`.
7. Abra `/solicitudes`, `/compras`, `/proveedores-control` y desde un arte con revisión elija `/expedientes/version/ID`.

## Alcance

- Listado de solicitudes con filtros por empresa, SAP y estado.
- Compras con verificación preliminar de versión vigente (NO es autorización final ni verificación de proveedor).
- Registro de estados de proveedor por versión-país y evidencia de referencia.
- Expediente por revisión con PDF principal y nuevos adjuntos clasificados, guardados localmente o en el Drive configurado en Medigray.
- Separación por empresas autorizadas y controles básicos de módulo.
- Migración aditiva: tablas `mg2_provider_status` y `mg2_version_documents`. No altera las tablas existentes.

## Limitaciones explícitas

- No automatiza todavía la sustitución transaccional V2→V3; mantenga las activaciones bajo revisión manual.
- Los proveedores no están autenticando las recepciones desde una cuenta externa; el registro es declarativo.
- El enlace de evidencia de proveedor es una referencia de texto, no un archivo administrado.
- No hay verificación regulatoria completa ni firma electrónica validada.
- Google Drive exige su configuración y credenciales de servicio; no publique esas credenciales en GitHub.
- No se eliminan módulos por configuración global: el menú nuevo es estático; las rutas validan permisos empresariales y por módulo.
- Las plantillas de nueva versión requieren que exista un arte con revisión documental y país asignado.
- No implante el MVP con documentos farmacéuticos oficiales sin validación y revisión de seguridad.

## Reversión

Detenga el servidor y restaure `app.py` y `templates/base.html` desde la carpeta `respaldo_bloque2_...`. Mantenga la base de datos: las dos tablas nuevas no perjudican la versión anterior. No las elimine, porque pueden contener datos añadidos.

## Seguridad

El directorio `storage/`, `respaldos/`, `storage_respaldo/`, `respaldo_bloque2_*/` y credenciales deben estar excluidos de Git. El puerto 8000 de Codespaces debe quedar privado.
