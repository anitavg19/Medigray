# Medigray — Bloque 4: biblioteca documental

Instala una pantalla de **consulta** para revisiones y documentos por empresa y país, y una verificación de integridad SHA-256 para los archivos locales. Reutiliza la carga de archivos a expedientes del Bloque 2 y la configuración local/Drive de Medigray v2. **No cambia el esquema de SQLite ni realiza migración de datos.**

1. Detener Uvicorn (`Ctrl+C`). Guardar copia segura y externa de `storage/`.
2. Subir los 4 archivos a `/workspaces/Medigray` (junto a `app.py`), sin sobrescribir `app.py`.
3. Ejecutar `python instalar_bloque4.py`.
4. Ejecutar `python -m py_compile app.py medigray_bloque4.py`.
5. Iniciar Uvicorn, abrir `/biblioteca-documental`.
6. Seleccionar arte y revisión → **Expediente** para adjuntar PDF, DOCX o imagen. **Verificar** compara el hash SHA-256 de archivos locales.

**Limitaciones:** La verificación de Google Drive aparece como pendiente; no confirma respaldos de Drive ni el contenido remoto. La biblioteca incluye todas las revisiones cargadas con PDF principal; un arte sin versiones aún no aparece. Los adjuntos generales a un arte no asociados a una revisión no se listan aquí. Solo se muestran empresas del usuario. No es un módulo de firma electrónica ni un sustituto de validación regulatoria.

**Nota de seguridad:** no publique Codespaces ni las credenciales de Drive, y mantenga `storage/` fuera de Git. Para una implementación oficial se necesita reforzar pruebas de seguridad, restauración de respaldos, seguimiento de documentos y políticas de retención.
