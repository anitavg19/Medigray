MEDIGRAY — INTERFAZ ORDENADA V2

Esta actualización corrige la barra lateral sobrecargada y la página de catálogos.
NO modifica app.py ni la carpeta storage.

INSTALACIÓN
1. Suba Medigray_UI_Ordenada_V2.zip al directorio donde está app.py.
2. Ejecute: unzip -oq Medigray_UI_Ordenada_V2.zip
3. Ejecute: python instalar_interfaz.py
4. Compruebe: python -c "from jinja2 import Environment,FileSystemLoader; e=Environment(loader=FileSystemLoader('templates')); [e.get_template(f) for f in ('base.html','home.html','mgf_catalogos.html')]; print('Plantillas válidas')"
5. Actualice Chrome con Ctrl+Shift+R. Si no cambia, reinicie Uvicorn.

RESULTADO
- Menú lateral: Inicio, Artes vigentes, Solicitudes, Más herramientas.
- Inicio: tarjetas de acceso rápido y sección desplegada de herramientas adicionales.
- Catálogos: pestañas Productos / Proveedores y formularios que se despliegan solo cuando se necesitan.
- Mantiene la información, nombres de campos Jinja, rutas, POST y CSRF originales.

IMPORTANTE
Los permisos de seguridad se deben validar en app.py. Ocultar enlaces no sustituye el control de permisos.
La interfaz se basa en el código de Medigray disponible, no en una inspección directa del Codespace.
Si no se ve, asegúrese de que está ejecutando la versión actualizada y de que no haya modificaciones posteriores de instaladores que vuelvan a insertar enlaces.

RECUPERACIÓN
Si necesita revertir, copie los tres archivos desde la carpeta respaldo_interfaz_FECHA_HORA/ hasta templates/.
